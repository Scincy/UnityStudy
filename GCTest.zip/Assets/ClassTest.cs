﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClassTest : MonoBehaviour
{
    // Start is called before the first frame update

    public ClassTest(){
        Debug.Log("I was born!");
    }
    ~ClassTest()
    {
        Debug.Log("I Died x0x");
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
